LILITH DOWNLOAD DESK v1.2 — WINDOWS

NEW IN 1.2:
- Runs as a background Windows app with a system tray icon (pystray + Pillow).
- Launch uses pyw/pythonw: NO LONG-RUNNING COMMAND PROMPT.
- Closing the main window now hides it to the tray instead of exiting.
- Separate downloadable progress window with progress bar, speed, downloaded
  bytes, estimated remaining time and Pause / Resume buttons.
- Optional Start hidden with Windows toggle in the desktop app (no admin required).
- Browser companion provides a floating Download with Lilith button over
  detectable HTML5 videos, plus a right-click download context menu.
- Browser-to-desktop receiver now requires a private pairing key.

INSTALL:
1. Extract the FULL ZIP to a permanent folder (e.g., Documents\LilithDownloadDesk).
2. Double-click Install_and_Launch.bat ONCE. It installs free Python dependencies:
   yt-dlp, Pillow and pystray, then starts Lilith quietly.
3. Later use Launch.bat; it closes right away while the app stays running.
4. Run Create_Shortcuts.bat if you want a desktop shortcut you can pin to Start.
5. In the desktop app, enable Start hidden with Windows if desired.
6. Install the browser extension (see browser_extension/README_BROWSER_EXTENSION.txt).
7. Copy the browser pairing key from the desktop app and paste it into the extension popup.

HOW TO FIND LILITH AFTER CLOSING THE MAIN WINDOW:
- Click the ^ arrow by your Windows taskbar clock if the tray icon is hidden.
- Right-click Lilith's purple moon icon. Choose Open Lilith, Show download
  progress, Pause active download, or Quit Lilith completely.
- Closing the standalone progress window does NOT stop the download.
- If pystray is missing, closing the app exits normally (safe fallback).

THE VIDEO BUTTON:
- The floating button appears on videos that expose ordinary HTML5 <video> elements.
- Click Download this video to queue the current page.
- Click Choose quality in Lilith to inspect available formats in the desktop app.
- Some sites are unsupported; the app does not circumvent DRM.

OTHER FEATURES:
- yt-dlp handles supported video sites with quality choices, clips and video merging.
- aria2c (optional) enables multi-connection direct file downloads.
- Python built-in downloader supports safe Range-based resume for direct files.
- FFmpeg (optional) supports MP4 conversion for AI uploads.
- Browser cookie import via yt-dlp is optional and stays local.

NOTES:
- Download speed & ETA are estimates. yt-dlp may restart progress when it
  downloads separate video and audio streams before merging.
- Resume depends on the website supporting HTTP range requests and link validity.
- The extension sends page URLs, not every underlying streaming media request.
- No administrator permissions are needed for Windows startup or background mode.
- Uninstall: disable Windows startup in the UI, quit via tray, remove extension,
  and delete extracted app files. Job settings are under %%LOCALAPPDATA%%\LilithDownloadDesk.
- v1.2 is a Python/Windows build, NOT a packaged standalone Windows .exe.
- Installer requires internet access to install Python packages.

LIMITATIONS:
- Not a full IDM replacement for deep browser interception.
- DRM-protected and unauthorized protected streams are not supported.
- Only save media you are allowed to download.
- Browser extension has broad page access to locate video elements, but only
  sends URLs when requested via an explicit click.
