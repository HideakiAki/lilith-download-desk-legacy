const ENDPOINT = 'http://127.0.0.1:51234';

async function sendToLilith(data) {
  const { pairingKey } = await chrome.storage.local.get('pairingKey');
  if (!pairingKey) return { ok: false, error: 'Pair the extension first: open its toolbar popup and paste your Lilith pairing key.' };
  const path = data.action === 'inspect' ? '/inspect' : '/add';
  const response = await fetch(ENDPOINT + path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Lilith-Token': pairingKey },
    body: JSON.stringify({ url: data.url, title: data.title || '', mode: data.mode || 'Video page' })
  });
  if (response.status === 403) return { ok: false, error: 'Pairing key rejected. Copy a fresh key from the Lilith desktop app.' };
  if (!response.ok) return { ok: false, error: `Lilith receiver returned HTTP ${response.status}.` };
  return { ok: true };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type !== 'lilith-send') return;
  sendToLilith(message)
    .then(sendResponse)
    .catch(() => sendResponse({ ok: false, error: 'Cannot connect. Launch Lilith first and enable its browser receiver.' }));
  return true;
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'lilith-link', title: 'Download with Lilith',
    contexts: ['link'], documentUrlPatterns: ['http://*/*', 'https://*/*']
  });
  chrome.contextMenus.create({
    id: 'lilith-page', title: 'Send page to Lilith',
    contexts: ['page', 'video'], documentUrlPatterns: ['http://*/*', 'https://*/*']
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const url = info.linkUrl || info.pageUrl || tab?.url;
  if (!url || !/^https?:\/\//i.test(url)) return;
  const mode = info.linkUrl ? 'Auto detect' : 'Video page';
  try { await sendToLilith({ url, title: tab?.title || '', mode, action: 'add' }); }
  catch (_err) { /* Popup offers an actionable connection error. */ }
});
