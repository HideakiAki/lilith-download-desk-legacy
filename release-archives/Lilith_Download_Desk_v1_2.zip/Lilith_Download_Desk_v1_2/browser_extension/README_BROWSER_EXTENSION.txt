LILITH DOWNLOAD COMPANION v1.2 — CHROME / EDGE

SETUP:
1. Run Install_and_Launch.bat (first time) or Launch.bat (later).
2. The Python app will keep running in the Windows notification area after you close the main window.
3. Open chrome://extensions or edge://extensions.
4. Turn on Developer mode and choose Load unpacked.
5. Select the browser_extension folder extracted from this ZIP.
   If an older Lilith companion is installed, REMOVE it first to avoid duplicate floating buttons.
6. Open Lilith desktop app. Click Copy browser pairing key in the right sidebar.
7. Click the extension toolbar icon; paste the key into Pairing key and click Save pairing key.
8. Open a normal website containing an HTML5 video. You should see a small purple
   'Download with Lilith' button at the top edge of the video.
9. Click the button -> Download this video OR Choose quality in Lilith.
   You can also open the extension popup and send the current tab.
10. To download ordinary links, right-click one -> Download with Lilith.

SECURITY / LIMITATIONS:
- Browser sends a URL only when you click the button or context menu.
- The extension has permission to detect HTML5 <video> elements on web pages. It
  does not record browsing history, intercept requests, or send cookies.
- The desktop receiver listens only on 127.0.0.1 and requires a private pairing key.
- This button cannot detect protected DRM video or every proprietary player.
- For video pages, yt-dlp attempts to find supported stream formats.
- Some players may use a blob/DRM stream; not all sites are supported.
- Available format selection opens in the desktop app, not in the floating button.
- This is not yet a full browser request interceptor like IDM.
