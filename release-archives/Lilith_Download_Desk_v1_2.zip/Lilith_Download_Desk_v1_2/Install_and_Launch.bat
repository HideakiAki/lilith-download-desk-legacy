@echo off
setlocal
cd /d "%~dp0"
title Lilith Download Desk Installer
where py >nul 2>nul
if %errorlevel%==0 (
  py -m pip install --upgrade "yt-dlp[default]" pillow pystray
  if errorlevel 1 goto :fail
  call "%~dp0Launch.bat"
  exit /b 0
)
where python >nul 2>nul
if %errorlevel%==0 (
  python -m pip install --upgrade "yt-dlp[default]" pillow pystray
  if errorlevel 1 goto :fail
  call "%~dp0Launch.bat"
  exit /b 0
)
echo Could not locate Python. Please install Python 3.10+ and retry.
goto :fail
:fail
echo Installation failed. See errors above.
pause
exit /b 1
