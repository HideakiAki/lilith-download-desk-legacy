LILITH BROWSER COMPANION (CHROME / EDGE)

This extension sends the CURRENT TAB URL to the desktop app on:
http://127.0.0.1:51234/add

HOW TO INSTALL (UNPACKED)
1. Open Chrome or Edge.
2. Go to chrome://extensions or edge://extensions.
3. Turn ON Developer mode.
4. Click Load unpacked.
5. Select this browser_extension folder.
6. Make sure Lilith Download Desk is already running.
7. Open a video page, click the extension icon, and choose Send current tab.

NOTES
- This is not a full network-sniffing IDM replacement. It sends the current tab URL.
- It works best for pages that yt-dlp can process.
- For private/signed-in sites, choose Browser login inside Lilith when supported.
