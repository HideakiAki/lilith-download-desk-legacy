async function getCurrentTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0];
}

document.getElementById('send').addEventListener('click', async () => {
  const status = document.getElementById('status');
  status.textContent = 'Sending...';
  try {
    const tab = await getCurrentTab();
    const mode = document.getElementById('mode').value;
    const resp = await fetch('http://127.0.0.1:51234/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: tab.url, title: tab.title || '', mode })
    });
    if (!resp.ok) throw new Error('Local app did not accept the link.');
    status.textContent = 'Sent to Lilith successfully ♡';
  } catch (err) {
    status.textContent = 'Failed: open Lilith first, then try again.';
    console.error(err);
  }
});
