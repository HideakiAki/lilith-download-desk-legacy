#!/usr/bin/env python3
"""Lilith Download Desk: local Windows video/file download queue.

Requires Python 3.10+ and yt-dlp; optional aria2c and ffmpeg.
Adds local browser companion receiver and video quality inspection.
"""
from __future__ import annotations

import json
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
import tkinter as tk
import urllib.error
import urllib.parse
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

APP_NAME = "Lilith Download Desk"
APP_VERSION = "1.1"
APP_DIR = Path(os.getenv("LOCALAPPDATA") or (Path.home() / ".local")) / "LilithDownloadDesk"
JOBS_FILE = APP_DIR / "jobs.json"
SETTINGS_FILE = APP_DIR / "settings.json"
DEFAULT_DOWNLOADS = Path.home() / "Downloads" / "Lilith Downloads"
DIRECT_EXTENSIONS = {
    ".zip", ".rar", ".7z", ".exe", ".msi", ".iso", ".pdf", ".apk",
    ".tar", ".gz", ".bz2", ".xz", ".bin", ".dmg", ".msix", ".deb",
    ".mp4", ".webm", ".mkv", ".mov", ".avi", ".mp3", ".flac",
    ".wav", ".jpg", ".jpeg", ".png", ".gif", ".webp", ".srt",
    ".epub", ".csv", ".json", ".txt", ".blend", ".vrm", ".pptx",
}
BG = "#16131f"
PANEL = "#231b31"
FG = "#efe7fb"
MUTED = "#b8a8ca"
ACCENT = "#a86be3"
ACCENT_2 = "#7d4ac0"
HIGHLIGHT = "#f4d7ff"
ERROR = "#f1a5aa"
SERVER_PORT = 51234


def url_is_valid(value: str) -> bool:
    try:
        p = urllib.parse.urlsplit(value)
        return p.scheme.lower() in ("http", "https") and bool(p.netloc)
    except ValueError:
        return False


def detect_mode(url: str, requested: str) -> str:
    if requested in ("Video page", "Direct file"):
        return "video" if requested == "Video page" else "file"
    ext = Path(urllib.parse.unquote(urllib.parse.urlsplit(url).path)).suffix.lower()
    return "file" if ext in DIRECT_EXTENSIONS else "video"


def safe_filename(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip().rstrip(". ")
    if not name or name in {".", ".."}:
        name = "download.bin"
    root = name.split(".")[0].upper()
    if root in {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}:
        name = "_" + name
    return name[:180]


def direct_filename(url: str) -> str:
    filename = Path(urllib.parse.unquote(urllib.parse.urlsplit(url).path)).name
    return safe_filename(filename or "download.bin")


def parse_percent(line: str) -> str | None:
    hits = re.findall(r"(?<!\d)(\d{1,3}(?:\.\d+)?)%", line)
    if hits:
        value = float(hits[-1])
        if 0 <= value <= 100:
            return f"{value:.1f}%"
    return None


def subprocess_flags() -> int:
    return getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0


def stop_process(proc: subprocess.Popen | None) -> None:
    if proc is None or proc.poll() is not None:
        return
    try:
        if os.name == "nt":
            subprocess.run(
                ["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=subprocess_flags(), timeout=6,
            )
        else:
            proc.terminate()
        if proc.poll() is None:
            proc.terminate()
    except (OSError, subprocess.TimeoutExpired):
        try:
            proc.terminate()
        except OSError:
            pass


class DownloadDesk:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(f"{APP_NAME} v{APP_VERSION}")
        self.root.geometry("1180x830")
        self.root.minsize(940, 700)
        self.root.configure(background=BG)
        self.events: queue.Queue = queue.Queue()
        self.jobs: list[dict] = []
        self.active_job_id: str | None = None
        self.active_stop: threading.Event | None = None
        self.active_proc: subprocess.Popen | None = None
        self.conversion_proc: subprocess.Popen | None = None
        self.converting = False
        self.running = True
        self.auto_run = False
        self.server: ThreadingHTTPServer | None = None
        self.server_thread: threading.Thread | None = None
        self.settings = {
            "receiver_enabled": True,
            "receiver_port": SERVER_PORT,
            "last_format_id": "",
            "last_format_label": "Auto / best available",
        }
        self.format_map: dict[str, str] = {}
        self._restore_settings()
        self._restore()
        self._style()
        self._create_ui()
        self._refresh_tree()
        self.root.after(120, self._pump)
        self.root.protocol("WM_DELETE_WINDOW", self._close)
        self._log("Welcome home, Master. Lilith is ready to catch downloads for you. ♡")
        self._log("yt-dlp handles video pages; aria2c improves direct downloads if installed.")
        if shutil.which("ffmpeg") is None:
            self._log("FFmpeg is not detected in PATH. MP4 conversion will be unavailable until it is installed.")
        if shutil.which("aria2c") is None:
            self._log("aria2c is optional and not detected. Direct downloads will use safe single-stream Python resume.")
        if self.receiver_enabled_var.get():
            self._start_receiver(initial=True)

    def _style(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure(".", background=BG, foreground=FG, font=("Segoe UI", 10))
        s.configure("TFrame", background=BG)
        s.configure("Card.TFrame", background=PANEL)
        s.configure("TLabel", background=BG, foreground=FG)
        s.configure("Card.TLabel", background=PANEL, foreground=FG)
        s.configure("Title.TLabel", font=("Segoe UI Semibold", 22), foreground=HIGHLIGHT)
        s.configure("Secondary.TLabel", foreground=MUTED)
        s.configure("PanelTitle.TLabel", background=PANEL, foreground=HIGHLIGHT, font=("Segoe UI Semibold", 11))
        s.configure("TButton", padding=(11, 7), background=PANEL, foreground=FG, borderwidth=1)
        s.map("TButton", background=[("active", "#413051")])
        s.configure("Accent.TButton", background=ACCENT_2, foreground="white")
        s.map("Accent.TButton", background=[("active", ACCENT)])
        s.configure("TEntry", fieldbackground="#2a2238", foreground=FG, insertcolor=FG)
        s.configure("TCombobox", fieldbackground="#2a2238", background=PANEL, foreground=FG)
        s.map("TCombobox", fieldbackground=[("readonly", "#2a2238")], foreground=[("readonly", FG)])
        s.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=FG, rowheight=28, borderwidth=0)
        s.map("Treeview", background=[("selected", "#68468a")], foreground=[("selected", "white")])
        s.configure("Treeview.Heading", background="#332a43", foreground=FG, relief="flat")
        s.configure("TCheckbutton", background=BG, foreground=FG)

    def _create_ui(self):
        main = ttk.Frame(self.root, padding=14)
        main.pack(fill="both", expand=True)
        header = ttk.Frame(main)
        header.pack(fill="x", pady=(0, 10))
        ttk.Label(header, text="Lilith Download Desk ♡", style="Title.TLabel").pack(anchor="w")
        ttk.Label(header, text="Anime-flavored downloader for videos, resumable files, and AI-ready MP4 prep.", style="Secondary.TLabel").pack(anchor="w")

        top = ttk.Frame(main)
        top.pack(fill="both", expand=True)
        left = ttk.Frame(top)
        left.pack(side="left", fill="both", expand=True)
        right = ttk.Frame(top)
        right.pack(side="left", fill="y", padx=(12, 0))

        entry = ttk.Frame(left)
        entry.pack(fill="x")
        ttk.Label(entry, text="Download URL").pack(side="left", padx=(0, 9))
        self.url_var = tk.StringVar()
        self.url_entry = ttk.Entry(entry, textvariable=self.url_var)
        self.url_entry.pack(side="left", fill="x", expand=True)
        ttk.Button(entry, text="Paste", command=self._paste).pack(side="left", padx=(8, 0))

        controls = ttk.Frame(left)
        controls.pack(fill="x", pady=(8, 6))
        ttk.Label(controls, text="Type").pack(side="left")
        self.mode_var = tk.StringVar(value="Auto detect")
        ttk.Combobox(controls, textvariable=self.mode_var, state="readonly", width=14,
                     values=["Auto detect", "Video page", "Direct file"]).pack(side="left", padx=(7, 16))
        ttk.Label(controls, text="Quick quality").pack(side="left")
        self.quality_var = tk.StringVar(value="Best")
        ttk.Combobox(controls, textvariable=self.quality_var, state="readonly", width=12,
                     values=["Best", "1080p max", "720p max"]).pack(side="left", padx=(7, 16))
        ttk.Label(controls, text="Browser login").pack(side="left")
        self.cookie_var = tk.StringVar(value="None")
        ttk.Combobox(controls, textvariable=self.cookie_var, state="readonly", width=11,
                     values=["None", "Chrome", "Edge", "Firefox", "Brave"]).pack(side="left", padx=(7, 16))
        ttk.Button(controls, text="Inspect qualities", command=self._inspect_qualities).pack(side="left")

        self.selected_format_label = tk.StringVar(value=self.settings.get("last_format_label", "Auto / best available"))
        ttk.Label(left, textvariable=self.selected_format_label, style="Secondary.TLabel").pack(anchor="w", pady=(0, 8))

        folder_line = ttk.Frame(left)
        folder_line.pack(fill="x", pady=(0, 10))
        ttk.Label(folder_line, text="Save to").pack(side="left", padx=(0, 11))
        self.folder_var = tk.StringVar(value=str(DEFAULT_DOWNLOADS))
        ttk.Entry(folder_line, textvariable=self.folder_var).pack(side="left", fill="x", expand=True)
        ttk.Button(folder_line, text="Browse", command=self._browse_folder).pack(side="left", padx=(8, 0))
        ttk.Button(folder_line, text="Open folder", command=self._open_folder).pack(side="left", padx=(7, 0))

        buttons = ttk.Frame(left)
        buttons.pack(fill="x", pady=(0, 12))
        ttk.Button(buttons, text="+ Add download", style="Accent.TButton", command=self._add).pack(side="left", padx=(0, 9))
        ttk.Button(buttons, text="▶ Start queue", command=self._start).pack(side="left", padx=(0, 9))
        ttk.Button(buttons, text="Ⅱ Pause selected", command=self._pause_selected).pack(side="left", padx=(0, 9))
        ttk.Button(buttons, text="↻ Resume selected", command=self._resume_selected).pack(side="left", padx=(0, 9))
        ttk.Button(buttons, text="Remove", command=self._remove_selected).pack(side="left")

        self.tree = ttk.Treeview(left, columns=("mode", "status", "progress", "folder"), show="tree headings", height=10)
        self.tree.heading("#0", text="Link / File")
        self.tree.heading("mode", text="Type")
        self.tree.heading("status", text="Status")
        self.tree.heading("progress", text="Progress")
        self.tree.heading("folder", text="Destination")
        self.tree.column("#0", width=320, stretch=True)
        self.tree.column("mode", width=85, stretch=False)
        self.tree.column("status", width=105, stretch=False)
        self.tree.column("progress", width=90, stretch=False)
        self.tree.column("folder", width=230, stretch=True)
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._update_selection)

        prep = ttk.Frame(left)
        prep.pack(fill="x", pady=(12, 6))
        ttk.Label(prep, text="Prepare video for AI sharing:", style="Secondary.TLabel").pack(side="left")
        ttk.Button(prep, text="Convert / compress to MP4 (H.264, 720p)", command=self._convert_dialog).pack(side="left", padx=(10, 0))

        trim = ttk.Frame(left)
        trim.pack(fill="x", pady=(0, 8))
        ttk.Label(trim, text="Start (seconds)").pack(side="left")
        self.trim_start = tk.StringVar()
        ttk.Entry(trim, width=9, textvariable=self.trim_start).pack(side="left", padx=(7, 18))
        ttk.Label(trim, text="Duration (seconds)").pack(side="left")
        self.trim_duration = tk.StringVar()
        ttk.Entry(trim, width=9, textvariable=self.trim_duration).pack(side="left", padx=(7, 0))
        ttk.Label(trim, text="Leave blank to convert the whole video", style="Secondary.TLabel").pack(side="left", padx=(14, 0))

        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(left, textvariable=self.status_var, style="Secondary.TLabel").pack(anchor="w", pady=(4, 4))
        self.log_box = tk.Text(left, height=8, bg="#15121d", fg="#d3c5e4", insertbackground=FG,
                               font=("Consolas", 9), wrap="word", state="disabled", relief="flat")
        self.log_box.pack(fill="x")

        info = tk.Frame(right, bg=PANEL, bd=0, highlightthickness=1, highlightbackground="#312544")
        info.pack(fill="y", expand=True)
        info.grid_columnconfigure(0, weight=1)
        tk.Label(info, text="Lilith Companion", bg=PANEL, fg=HIGHLIGHT, font=("Segoe UI Semibold", 12)).grid(row=0, column=0, sticky="w", padx=12, pady=(12, 2))
        tk.Label(info, text="Cute helper features for easier grabs ♡", bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).grid(row=1, column=0, sticky="w", padx=12, pady=(0, 10))

        self.receiver_enabled_var = tk.BooleanVar(value=bool(self.settings.get("receiver_enabled", True)))
        ttk.Checkbutton(info, text="Listen for browser extension links", variable=self.receiver_enabled_var,
                        command=self._toggle_receiver).grid(row=2, column=0, sticky="w", padx=12, pady=(0, 6))
        self.receiver_status_var = tk.StringVar(value="Receiver idle")
        tk.Label(info, textvariable=self.receiver_status_var, bg=PANEL, fg=FG, justify="left", wraplength=280,
                 font=("Segoe UI", 9)).grid(row=3, column=0, sticky="w", padx=12, pady=(0, 8))
        ttk.Button(info, text="Copy receiver URL", command=self._copy_receiver_url).grid(row=4, column=0, sticky="w", padx=12, pady=(0, 10))

        tk.Label(info, text="Inspected video formats", bg=PANEL, fg=HIGHLIGHT, font=("Segoe UI Semibold", 11)).grid(row=5, column=0, sticky="w", padx=12, pady=(8, 6))
        self.format_list = tk.Listbox(info, height=16, bg="#1a1424", fg=FG, selectbackground="#69408a", selectforeground="white",
                                      relief="flat", highlightthickness=1, highlightbackground="#312544")
        self.format_list.grid(row=6, column=0, sticky="nsew", padx=12)
        info.grid_rowconfigure(6, weight=1)
        btns = ttk.Frame(info)
        btns.grid(row=7, column=0, sticky="ew", padx=12, pady=10)
        ttk.Button(btns, text="Use selected quality", command=self._use_selected_format).pack(side="left")
        ttk.Button(btns, text="Clear quality override", command=self._clear_selected_format).pack(side="left", padx=(8, 0))

        tip = (
            "Tip:\n"
            "• For supported video pages, click Inspect qualities first.\n"
            "• The browser companion can send the current tab directly to Lilith.\n"
            "• For private sites, use Browser login when yt-dlp supports it."
        )
        tk.Label(info, text=tip, bg=PANEL, fg=MUTED, justify="left", wraplength=280, font=("Segoe UI", 9)).grid(row=8, column=0, sticky="w", padx=12, pady=(0, 12))

        self.url_entry.focus_set()

    def _paste(self):
        try:
            self.url_var.set(self.root.clipboard_get().strip())
        except tk.TclError:
            messagebox.showinfo("Clipboard", "No text URL is available on the clipboard.")

    def _browse_folder(self):
        folder = filedialog.askdirectory(initialdir=self.folder_var.get() or str(Path.home()))
        if folder:
            self.folder_var.set(folder)

    def _open_folder(self):
        folder = Path(self.folder_var.get()).expanduser()
        folder.mkdir(parents=True, exist_ok=True)
        try:
            if os.name == "nt":
                os.startfile(str(folder))
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(folder)])
            else:
                subprocess.Popen(["xdg-open", str(folder)])
        except OSError as exc:
            messagebox.showerror("Open folder", str(exc))

    def _current_format_id(self) -> str:
        return str(self.settings.get("last_format_id", "") or "")

    def _add(self, external_url: str | None = None, external_title: str | None = None):
        url = (external_url or self.url_var.get()).strip()
        if not url_is_valid(url):
            messagebox.showerror("Invalid URL", "Paste a full http:// or https:// URL.")
            return
        folder = str(Path(self.folder_var.get()).expanduser())
        try:
            Path(folder).mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            messagebox.showerror("Folder error", str(exc))
            return
        mode = detect_mode(url, self.mode_var.get())
        job = {
            "id": str(uuid.uuid4()), "url": url, "mode": mode, "folder": folder,
            "quality": self.quality_var.get(), "cookies": self.cookie_var.get(),
            "status": "Queued", "progress": "0%", "output": "", "title": external_title or "",
            "format_id": self._current_format_id(), "format_label": self.settings.get("last_format_label", "Auto / best available"),
        }
        self.jobs.append(job)
        self._save()
        self._refresh_tree()
        self.tree.selection_set(job["id"])
        self.tree.see(job["id"])
        self.url_var.set("")
        host = urllib.parse.urlsplit(url).netloc
        self._log(f"Added {mode} download: {external_title or host}")
        if self.auto_run:
            self._maybe_start_next()

    def _selected(self) -> dict | None:
        selected = self.tree.selection()
        if not selected:
            return None
        return next((x for x in self.jobs if x["id"] == selected[0]), None)

    def _update_selection(self, _event=None):
        job = self._selected()
        if job:
            extra = f" [{job.get('format_label')}]" if job.get("format_id") else ""
            self.status_var.set(f"{job['status']}: {job['url'][:110]}{extra}")

    def _refresh_tree(self):
        old = self.tree.selection() if hasattr(self, "tree") else ()
        for item in self.tree.get_children():
            self.tree.delete(item)
        for job in self.jobs:
            display = job.get("title") or (Path(job["output"]).name if job.get("output") else job["url"].split("?")[0])
            if len(display) > 110:
                display = display[:107] + "..."
            self.tree.insert("", "end", iid=job["id"], text=display, values=(
                job["mode"], job["status"], job["progress"], job["folder"]
            ))
        for iid in old:
            if self.tree.exists(iid):
                self.tree.selection_add(iid)

    def _refresh_row(self, job: dict):
        if self.tree.exists(job["id"]):
            display = job.get("title") or (Path(job["output"]).name if job.get("output") else job["url"].split("?")[0])
            if len(display) > 110:
                display = display[:107] + "..."
            self.tree.item(job["id"], text=display, values=(job["mode"], job["status"], job["progress"], job["folder"]))

    def _start(self):
        self.auto_run = True
        self._maybe_start_next()

    def _maybe_start_next(self):
        if not self.running or not self.auto_run or self.active_job_id:
            return
        job = next((x for x in self.jobs if x["status"] == "Queued"), None)
        if job is None:
            self.auto_run = False
            self.status_var.set("Queue complete (or no queued items)")
            return
        self.active_job_id = job["id"]
        self.active_stop = threading.Event()
        job["status"] = "Downloading"
        self._refresh_row(job)
        self._save()
        self.status_var.set(f"Downloading: {urllib.parse.urlsplit(job['url']).netloc}")
        threading.Thread(target=self._download_worker, args=(job.copy(), self.active_stop), daemon=True).start()

    def _pause_selected(self):
        job = self._selected()
        if not job:
            return
        if job["status"] == "Downloading" and job["id"] == self.active_job_id:
            job["status"] = "Pausing"
            if self.active_stop:
                self.active_stop.set()
            stop_process(self.active_proc)
        elif job["status"] == "Queued":
            job["status"] = "Paused"
        self._refresh_row(job)
        self._save()

    def _resume_selected(self):
        job = self._selected()
        if not job or job["status"] not in ("Paused", "Failed"):
            return
        job["status"] = "Queued"
        self._refresh_row(job)
        self._save()
        self.auto_run = True
        self._maybe_start_next()

    def _remove_selected(self):
        job = self._selected()
        if not job:
            return
        if job["id"] == self.active_job_id:
            messagebox.showinfo("Pause first", "Pause this download, then remove it. Partial files are never deleted automatically.")
            return
        self.jobs = [x for x in self.jobs if x["id"] != job["id"]]
        self._refresh_tree()
        self._save()
        self._maybe_start_next()

    def _inspect_qualities(self):
        url = self.url_var.get().strip()
        if not url_is_valid(url):
            messagebox.showerror("Invalid URL", "Paste a supported video page URL first.")
            return
        self.format_list.delete(0, "end")
        self.format_map = {}
        self.format_list.insert("end", "Inspecting… please wait")
        threading.Thread(target=self._inspect_worker, args=(url, self.cookie_var.get()), daemon=True).start()

    def _inspect_worker(self, url: str, cookie_mode: str):
        try:
            try:
                import yt_dlp  # noqa: F401
            except ImportError as exc:
                raise RuntimeError("yt-dlp is missing. Run Install_and_Launch.bat first.") from exc
            cmd = [sys.executable, "-m", "yt_dlp", "--dump-single-json", "--no-warnings", "--no-playlist", "--", url]
            if cookie_mode != "None":
                cmd[3:3] = ["--cookies-from-browser", cookie_mode.lower()]
            proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                                  creationflags=subprocess_flags(), timeout=120)
            if proc.returncode != 0:
                raise RuntimeError(proc.stderr.strip() or proc.stdout.strip() or "Unable to inspect formats.")
            info = json.loads(proc.stdout)
            formats = info.get("formats") or []
            title = info.get("title") or urllib.parse.urlsplit(url).netloc
            rows = []
            seen = set()
            for f in formats:
                fid = str(f.get("format_id", ""))
                ext = f.get("ext") or "?"
                height = f.get("height")
                width = f.get("width")
                vcodec = f.get("vcodec") or "?"
                acodec = f.get("acodec") or "?"
                proto = f.get("protocol") or "?"
                approx = f.get("filesize") or f.get("filesize_approx")
                note = f.get("format_note") or ""
                fps = f.get("fps")
                if not fid or fid in seen:
                    continue
                seen.add(fid)
                if vcodec == "none":
                    kind = "audio"
                    res = "audio only"
                else:
                    kind = "video"
                    res = f"{width or '?'}x{height or '?'}"
                size = f"{approx / (1024*1024):.1f} MiB" if isinstance(approx, (int, float)) else "?"
                fps_txt = f" {int(fps)}fps" if fps else ""
                label = f"{fid} — {res}{fps_txt} — {ext} — {kind} — {size} — {note or proto}"
                rows.append((0 if kind == 'video' else 1, -(height or 0), label, fid))
            rows.sort()
            items = [r[2:] for r in rows[:120]]
            self.events.put(("formats", title, items))
        except Exception as exc:
            self.events.put(("formats_error", str(exc)))

    def _use_selected_format(self):
        sel = self.format_list.curselection()
        if not sel:
            return
        label = self.format_list.get(sel[0])
        fid = self.format_map.get(label)
        if not fid:
            return
        self.settings["last_format_id"] = fid
        self.settings["last_format_label"] = label
        self.selected_format_label.set(f"Selected format override: {label}")
        self._save_settings()
        self._log(f"Selected format override set: {label}")

    def _clear_selected_format(self):
        self.settings["last_format_id"] = ""
        self.settings["last_format_label"] = "Auto / best available"
        self.selected_format_label.set("Selected format override: Auto / best available")
        self._save_settings()
        self._log("Format override cleared. New video jobs will use the quick quality selector again.")

    def _download_worker(self, job: dict, stop: threading.Event):
        try:
            if job["mode"] == "video":
                output = self._download_video(job, stop)
            elif shutil.which("aria2c"):
                output = self._download_aria2(job, stop)
            else:
                output = self._download_python(job, stop)
            self.events.put(("done", job["id"], bool(not stop.is_set()), output or ""))
        except Exception as exc:
            self.events.put(("error", job["id"], str(exc)))

    def _run_command(self, cmd: list[str], job: dict, stop: threading.Event) -> str:
        output = ""
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                stdin=subprocess.DEVNULL, text=True, encoding="utf-8", errors="replace",
                                bufsize=1, creationflags=subprocess_flags())
        self.active_proc = proc
        try:
            assert proc.stdout is not None
            for raw in proc.stdout:
                if stop.is_set():
                    stop_process(proc)
                    break
                line = raw.strip()
                if not line:
                    continue
                if line.startswith("OUTPUT_FILE:"):
                    output = line.split(":", 1)[1].strip()
                percent = parse_percent(line)
                if percent and ("[download]" in line or "%" in line):
                    self.events.put(("progress", job["id"], percent))
                if not (line.startswith("[download]") and percent):
                    self.events.put(("log", line[:320]))
            try:
                code = proc.wait(timeout=8)
            except subprocess.TimeoutExpired:
                stop_process(proc)
                code = proc.wait(timeout=4)
            if code != 0 and not stop.is_set():
                raise RuntimeError(f"Downloader exited with error code {code}. See the log for details.")
            return output
        finally:
            self.active_proc = None
            try:
                if proc.stdout:
                    proc.stdout.close()
            except OSError:
                pass

    def _download_video(self, job: dict, stop: threading.Event) -> str:
        try:
            import yt_dlp  # noqa: F401
        except ImportError as exc:
            raise RuntimeError("yt-dlp is missing. Run Install_and_Launch.bat or: py -m pip install -U 'yt-dlp[default]' ") from exc
        cmd = [sys.executable, "-m", "yt_dlp", "--newline", "--continue", "--no-overwrites",
               "--no-playlist", "--windows-filenames", "--retries", "10", "--fragment-retries", "10",
               "--socket-timeout", "30", "--concurrent-fragments", "4",
               "--merge-output-format", "mp4", "--print", "after_move:OUTPUT_FILE:%(filepath)s",
               "-o", str(Path(job["folder"]) / "%(title).150s [%(id)s].%(ext)s")]
        explicit = str(job.get("format_id") or "")
        if explicit:
            if "audio only" in str(job.get("format_label", "")).lower():
                cmd.extend(["-f", explicit])
            else:
                cmd.extend(["-f", f"{explicit}+ba/{explicit}/bv*+ba/b"])
        elif job["quality"] == "1080p max":
            cmd.extend(["-f", "bv*[height<=1080]+ba/b[height<=1080]/b"])
        elif job["quality"] == "720p max":
            cmd.extend(["-f", "bv*[height<=720]+ba/b[height<=720]/b"])
        else:
            cmd.extend(["-f", "bv*+ba/b"])
        if job["cookies"] != "None":
            cmd.extend(["--cookies-from-browser", job["cookies"].lower()])
        cmd.extend(["--", job["url"]])
        self.events.put(("log", f"Video downloader started. {job.get('format_label') or job['quality']}"))
        return self._run_command(cmd, job, stop)

    def _download_aria2(self, job: dict, stop: threading.Event) -> str:
        cmd = ["aria2c", "--continue=true", "--always-resume=true", "--split=8",
               "--max-connection-per-server=8", "--min-split-size=1M", "--max-tries=10",
               "--retry-wait=4", "--timeout=30", "--connect-timeout=25",
               "--file-allocation=none", "--summary-interval=1", "--console-log-level=notice",
               "--dir", job["folder"], "--", job["url"]]
        self.events.put(("log", "aria2c started (8 connections max; resume requested)."))
        return self._run_command(cmd, job, stop)

    def _download_python(self, job: dict, stop: threading.Event) -> str:
        filename = direct_filename(job["url"])
        dest = Path(job["folder"]) / filename
        part = Path(str(dest) + ".part")
        meta_path = Path(str(part) + ".meta.json")
        if dest.exists():
            raise RuntimeError(f"Destination already exists: {dest.name}. Move/rename it before retrying.")
        resume_at = part.stat().st_size if part.exists() else 0
        headers = {"User-Agent": "LilithDownloadDesk/1.1 (compatible; Python urllib)"}
        if resume_at:
            headers["Range"] = f"bytes={resume_at}-"
            if meta_path.exists():
                try:
                    meta = json.loads(meta_path.read_text(encoding="utf-8"))
                    if meta.get("url") == job["url"] and meta.get("if_range"):
                        headers["If-Range"] = meta["if_range"]
                except (OSError, ValueError):
                    pass
        request = urllib.request.Request(job["url"], headers=headers)
        try:
            response = urllib.request.urlopen(request, timeout=30)
        except urllib.error.HTTPError as exc:
            if exc.code == 416 and resume_at:
                raise RuntimeError("Server rejected the saved resume offset (416); partial file was kept intact.") from exc
            raise RuntimeError(f"HTTP {exc.code}: {exc.reason}") from exc
        with response:
            status = response.status
            if resume_at and status != 206:
                raise RuntimeError("Server cannot resume this partial download (no HTTP 206). Existing .part was preserved.")
            if resume_at:
                content_range = response.headers.get("Content-Range", "")
                match = re.match(r"bytes\s+(\d+)-(\d+)/(\d+|\*)", content_range)
                if not match or int(match.group(1)) != resume_at:
                    raise RuntimeError("Server returned a mismatched byte range; existing .part was preserved.")
                total = int(match.group(3)) if match.group(3) != "*" else None
            else:
                length = response.headers.get("Content-Length")
                total = int(length) if length and length.isdigit() else None
                validator = response.headers.get("ETag") or response.headers.get("Last-Modified")
                try:
                    meta_path.write_text(json.dumps({"url": job["url"], "if_range": validator}), encoding="utf-8")
                except OSError:
                    pass
            self.events.put(("log", f"Direct HTTP download: {filename} ({'resuming' if resume_at else 'new'})."))
            count = resume_at
            last_report = 0.0
            with part.open("ab" if resume_at else "wb") as f:
                while not stop.is_set():
                    chunk = response.read(256 * 1024)
                    if not chunk:
                        break
                    f.write(chunk)
                    count += len(chunk)
                    now = time.monotonic()
                    if now - last_report >= 0.35:
                        self.events.put(("progress", job["id"], f"{count / total * 100:.1f}%" if total else f"{count / 1048576:.1f} MiB"))
                        last_report = now
            if stop.is_set():
                return ""
            if total is not None and count != total:
                raise RuntimeError(f"Incomplete transfer ({count} of {total} bytes); .part preserved for resume.")
            os.replace(part, dest)
            try:
                meta_path.unlink(missing_ok=True)
            except OSError:
                pass
            self.events.put(("progress", job["id"], "100%"))
            return str(dest)

    def _convert_dialog(self):
        if self.converting:
            messagebox.showinfo("Conversion", "A video is already being converted.")
            return
        if not shutil.which("ffmpeg"):
            messagebox.showerror("FFmpeg missing", "FFmpeg is required for video conversion. Install it and restart the app.")
            return
        src = filedialog.askopenfilename(title="Choose a video to prepare for AI",
                                         filetypes=[("Video files", "*.mp4 *.mkv *.mov *.webm *.avi *.ts *.m4v"), ("All files", "*.*")])
        if not src:
            return
        try:
            start = self._parse_positive(self.trim_start.get(), "Start time", zero_ok=True)
            duration = self._parse_positive(self.trim_duration.get(), "Duration", zero_ok=False)
        except ValueError as exc:
            messagebox.showerror("Clip settings", str(exc))
            return
        initial = str(Path(src).with_name(Path(src).stem + "_AI_720p.mp4"))
        output = filedialog.asksaveasfilename(title="Save AI-friendly MP4", defaultextension=".mp4",
                                              initialdir=str(Path(src).parent), initialfile=Path(initial).name,
                                              filetypes=[("MP4 video", "*.mp4")])
        if not output:
            return
        if Path(src).resolve() == Path(output).resolve():
            messagebox.showerror("Output", "Choose a different filename from the source video.")
            return
        if Path(output).exists():
            messagebox.showerror("Output", "The output file already exists. Choose a new filename.")
            return
        self.converting = True
        self.status_var.set("Converting video for AI sharing...")
        threading.Thread(target=self._convert_worker, args=(src, output, start, duration), daemon=True).start()

    @staticmethod
    def _parse_positive(value: str, label: str, zero_ok: bool) -> float | None:
        value = value.strip()
        if not value:
            return None
        try:
            result = float(value)
        except ValueError as exc:
            raise ValueError(f"{label} must be a number of seconds.") from exc
        if not (result < float("inf")) or result < 0 or (not zero_ok and result == 0):
            raise ValueError(f"{label} must be {'nonnegative' if zero_ok else 'positive' }.")
        return result

    def _convert_worker(self, src: str, output: str, start: float | None, duration: float | None):
        filter_expr = "scale=w='min(1280,iw)':h='min(720,ih)':force_original_aspect_ratio=decrease:force_divisible_by=2"
        cmd = ["ffmpeg", "-hide_banner", "-nostdin", "-n"]
        if start is not None:
            cmd.extend(["-ss", str(start)])
        cmd.extend(["-i", src])
        if duration is not None:
            cmd.extend(["-t", str(duration)])
        cmd.extend(["-map", "0:v:0", "-map", "0:a:0?", "-vf", filter_expr,
                    "-r", "30", "-c:v", "libx264", "-preset", "veryfast", "-crf", "27",
                    "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "96k", "-sn",
                    "-movflags", "+faststart", output])
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    stdin=subprocess.DEVNULL, encoding="utf-8", errors="replace", text=True,
                                    creationflags=subprocess_flags())
            self.conversion_proc = proc
            assert proc.stdout is not None
            for raw in proc.stdout:
                line = raw.strip()
                if line and ("time=" in line or "Error" in line or "Invalid" in line):
                    self.events.put(("log", "Convert: " + line[:250]))
            code = proc.wait()
            if code:
                self.events.put(("convert_error", f"FFmpeg failed (exit {code}). Check log."))
            else:
                self.events.put(("convert_done", output))
        except Exception as exc:
            self.events.put(("convert_error", str(exc)))
        finally:
            self.conversion_proc = None

    def _start_receiver(self, initial: bool = False):
        port = int(self.settings.get("receiver_port", SERVER_PORT))
        if self.server:
            return
        app = self

        class Handler(BaseHTTPRequestHandler):
            def do_OPTIONS(self):
                self.send_response(204)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
                self.send_header("Access-Control-Allow-Headers", "Content-Type")
                self.end_headers()

            def do_POST(self):
                if self.path.rstrip("/") not in ("/add", "/add-link"):
                    self.send_error(404)
                    return
                length = int(self.headers.get("Content-Length", "0") or "0")
                raw = self.rfile.read(length)
                try:
                    data = json.loads(raw.decode("utf-8"))
                except Exception:
                    self.send_error(400, "Bad JSON")
                    return
                url = str(data.get("url", "")).strip()
                title = str(data.get("title", "")).strip()
                mode = str(data.get("mode", "video")).strip()
                if not url_is_valid(url):
                    self.send_error(400, "Invalid URL")
                    return
                app.events.put(("external_add", url, title, mode))
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(json.dumps({"ok": True}).encode("utf-8"))

            def log_message(self, format, *args):
                return

        try:
            self.server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
            self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
            self.server_thread.start()
            self.receiver_status_var.set(f"Listening on http://127.0.0.1:{port}/add\nBrowser extension can send the active tab here.")
            if not initial:
                self._log(f"Browser receiver started on port {port}.")
        except OSError as exc:
            self.server = None
            self.receiver_enabled_var.set(False)
            self.receiver_status_var.set(f"Receiver failed: {exc}")
            self._log(f"Receiver failed to start: {exc}")

    def _stop_receiver(self):
        if self.server:
            try:
                self.server.shutdown()
                self.server.server_close()
            except OSError:
                pass
            self.server = None
            self.server_thread = None
            self.receiver_status_var.set("Receiver disabled")
            self._log("Browser receiver stopped.")

    def _toggle_receiver(self):
        enabled = bool(self.receiver_enabled_var.get())
        self.settings["receiver_enabled"] = enabled
        self._save_settings()
        if enabled:
            self._start_receiver()
        else:
            self._stop_receiver()

    def _copy_receiver_url(self):
        url = f"http://127.0.0.1:{int(self.settings.get('receiver_port', SERVER_PORT))}/add"
        self.root.clipboard_clear()
        self.root.clipboard_append(url)
        self._log("Receiver URL copied to clipboard.")

    def _log(self, message: str):
        if not self.running:
            return
        self.log_box.configure(state="normal")
        self.log_box.insert("end", message + "\n")
        line_count = int(self.log_box.index("end-1c").split(".")[0])
        if line_count > 350:
            self.log_box.delete("1.0", "90.0")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def _pump(self):
        if not self.running:
            return
        dirty = False
        try:
            while True:
                item = self.events.get_nowait()
                kind = item[0]
                if kind == "log":
                    self._log(item[1])
                elif kind == "progress":
                    job = next((x for x in self.jobs if x["id"] == item[1]), None)
                    if job:
                        job["progress"] = item[2]
                        self._refresh_row(job)
                elif kind == "formats":
                    title, items = item[1], item[2]
                    self.format_list.delete(0, "end")
                    self.format_map = {}
                    if not items:
                        self.format_list.insert("end", "No explicit formats found")
                    else:
                        for label, fid in items:
                            self.format_list.insert("end", label)
                            self.format_map[label] = fid
                    self._log(f"Loaded {len(items)} formats for: {title}")
                elif kind == "formats_error":
                    self.format_list.delete(0, "end")
                    self.format_map = {}
                    self.format_list.insert("end", "Inspection failed")
                    self._log("Format inspection failed: " + str(item[1]))
                    messagebox.showerror("Inspect qualities", str(item[1]))
                elif kind == "external_add":
                    url, title, mode = item[1], item[2], item[3]
                    old_mode = self.mode_var.get()
                    try:
                        if mode in ("Video page", "Direct file", "Auto detect"):
                            self.mode_var.set(mode)
                        self._add(external_url=url, external_title=title)
                    finally:
                        self.mode_var.set(old_mode)
                    self._log(f"Received from browser: {title or url}")
                elif kind in ("done", "error"):
                    job = next((x for x in self.jobs if x["id"] == item[1]), None)
                    if job:
                        stopped = self.active_stop.is_set() if self.active_stop else False
                        if stopped:
                            job["status"] = "Paused"
                            self._log("Paused. Partial download files were preserved.")
                        elif kind == "done" and item[2]:
                            job["status"] = "Completed"
                            job["progress"] = "100%"
                            if item[3]:
                                job["output"] = item[3]
                            self._log("Download completed.")
                        else:
                            job["status"] = "Failed"
                            self._log("Error: " + (item[2] if kind == "error" else "Download interrupted unexpectedly."))
                        self._refresh_row(job)
                        dirty = True
                    self.active_job_id = None
                    self.active_stop = None
                    self._maybe_start_next()
                elif kind == "convert_done":
                    self.converting = False
                    self.status_var.set("AI-friendly MP4 ready: " + str(item[1]))
                    self._log("Converted MP4: " + str(item[1]))
                    messagebox.showinfo("Conversion finished", "Saved AI-friendly MP4:\n" + str(item[1]))
                elif kind == "convert_error":
                    self.converting = False
                    self.status_var.set("Conversion failed")
                    self._log("Conversion failed: " + str(item[1]))
                    messagebox.showerror("Conversion failed", str(item[1]))
        except queue.Empty:
            pass
        if dirty:
            self._save()
        self.root.after(120, self._pump)

    def _restore(self):
        try:
            records = json.loads(JOBS_FILE.read_text(encoding="utf-8"))
            if not isinstance(records, list):
                return
            for job in records:
                if not isinstance(job, dict) or not url_is_valid(str(job.get("url", ""))):
                    continue
                if job.get("status") in ("Downloading", "Pausing", "Queued"):
                    job["status"] = "Paused"
                self.jobs.append(job)
        except (OSError, ValueError):
            pass

    def _save(self):
        try:
            APP_DIR.mkdir(parents=True, exist_ok=True)
            temp = JOBS_FILE.with_suffix(".tmp")
            temp.write_text(json.dumps(self.jobs, indent=2, ensure_ascii=False), encoding="utf-8")
            os.replace(temp, JOBS_FILE)
        except OSError as exc:
            self._log(f"Warning: unable to save job list: {exc}") if hasattr(self, "log_box") else None

    def _restore_settings(self):
        try:
            loaded = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                self.settings.update(loaded)
        except (OSError, ValueError):
            pass

    def _save_settings(self):
        try:
            APP_DIR.mkdir(parents=True, exist_ok=True)
            SETTINGS_FILE.write_text(json.dumps(self.settings, indent=2, ensure_ascii=False), encoding="utf-8")
        except OSError:
            pass

    def _close(self):
        self.running = False
        if self.active_stop:
            self.active_stop.set()
        stop_process(self.active_proc)
        stop_process(self.conversion_proc)
        self._stop_receiver()
        for job in self.jobs:
            if job["status"] in ("Downloading", "Pausing", "Queued"):
                job["status"] = "Paused"
        self._save()
        self._save_settings()
        self.root.destroy()


def main():
    root = tk.Tk()
    DownloadDesk(root)
    root.mainloop()


if __name__ == "__main__":
    main()
