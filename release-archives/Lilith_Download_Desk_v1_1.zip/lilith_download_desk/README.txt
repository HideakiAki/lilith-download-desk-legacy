LILITH DOWNLOAD DESK 1.1
Cute local Windows downloader with quality inspection and browser companion

WHAT'S NEW IN 1.1
- Softer anime-themed purple UI
- Inspect video formats / resolutions before adding a job
- Select a specific quality / format ID (or audio-only) for future video jobs
- Local browser receiver on http://127.0.0.1:51234/add
- Included Chrome/Edge extension folder to send the current tab directly

QUICK START
1. Unzip this folder wherever you like.
2. Double-click Install_and_Launch.bat once.
3. Next time, use Launch.bat.
4. Optional: load the browser_extension folder as an unpacked extension in Chrome/Edge.
5. For supported video pages:
   - paste a URL or use the browser companion
   - click Inspect qualities if you want specific resolutions/audio-only
   - click Use selected quality, then + Add download
6. For direct links (zip/mp4/exe/etc.), choose Direct file if auto-detect guesses wrong.
7. Click Start queue.
8. For sharing videos with AI tools, use Convert / compress to MP4.

MAIN FEATURES
- yt-dlp video downloads for many supported websites
- resumable direct file downloads
- optional aria2 multi-connection file downloading
- optional browser cookie import through yt-dlp's --cookies-from-browser
- MP4 conversion with FFmpeg for AI uploads
- lightweight browser companion to send the current tab to the app

DEPENDENCIES
Required: Python 3.10+ and yt-dlp
Optional: FFmpeg in PATH for MP4 conversion / merging
Optional: aria2c in PATH for faster direct file downloads

IMPORTANT LIMITATIONS
- The browser extension is a convenience sender, not a full interception extension like IDM.
- It does not automatically detect every media request on a webpage.
- DRM-protected streams and paywalled protected media are not supported.
- Resume depends on the server honoring HTTP range requests and links staying valid.
- Browser login only works where yt-dlp supports that website/browser combination.
- Downloaded media may be copyrighted; use only where you have permission.

FILES
- Lilith_Download_Desk.py           Main application
- Install_and_Launch.bat            Installs yt-dlp and launches the app
- Launch.bat                        Launches the app
- browser_extension/                Chrome/Edge companion

TROUBLESHOOTING
Inspect qualities fails:
- Update yt-dlp by rerunning Install_and_Launch.bat
- Try Browser login if the page needs a logged-in session

Extension fails to send:
- Make sure Lilith is running first
- Confirm the app says the receiver is listening on 127.0.0.1:51234
- Reload the extension after updates
