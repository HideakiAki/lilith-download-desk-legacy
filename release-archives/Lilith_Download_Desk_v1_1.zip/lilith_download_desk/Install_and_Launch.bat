@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -m pip install -U yt-dlp
  py Lilith_Download_Desk.py
  exit /b
)
where python >nul 2>nul
if %errorlevel%==0 (
  python -m pip install -U yt-dlp
  python Lilith_Download_Desk.py
  exit /b
)
echo Python was not found in PATH.
pause
