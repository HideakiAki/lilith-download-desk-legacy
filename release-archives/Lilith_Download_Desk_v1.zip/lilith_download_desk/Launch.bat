@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
    py -3 "%~dp0Lilith_Download_Desk.py"
) else (
    python "%~dp0Lilith_Download_Desk.py"
)
if errorlevel 1 pause
endlocal
