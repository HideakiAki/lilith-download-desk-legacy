@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
    set "PYCMD=py -3"
) else (
    where python >nul 2>&1
    if errorlevel 1 (
        echo Python was not found. Install Python 3.10+ from https://www.python.org/downloads/windows/
        pause
        exit /b 1
    )
    set "PYCMD=python"
)
echo Installing/updating yt-dlp...
%PYCMD% -m pip install --upgrade "yt-dlp[default]"
if errorlevel 1 (
    echo.
    echo yt-dlp could not be installed. Review the error above.
    pause
    exit /b 1
)
echo.
echo Launching Lilith Download Desk...
%PYCMD% "%~dp0Lilith_Download_Desk.py"
if errorlevel 1 pause
endlocal
