#!/usr/bin/env python3
"""Lilith Download Desk: local Windows video/file download queue.

Requires Python 3.10+ and yt-dlp; optional aria2c and ffmpeg.
No DRM circumvention, license reset, or browser extension.
"""
from __future__ import annotations

import json
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
import tkinter as tk
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

APP_NAME = "Lilith Download Desk"
APP_VERSION = "1.0"
APP_DIR = Path(os.getenv("LOCALAPPDATA") or (Path.home() / ".local")) / "LilithDownloadDesk"
JOBS_FILE = APP_DIR / "jobs.json"
DEFAULT_DOWNLOADS = Path.home() / "Downloads" / "Lilith Downloads"
DIRECT_EXTENSIONS = {
    ".zip", ".rar", ".7z", ".exe", ".msi", ".iso", ".pdf", ".apk",
    ".tar", ".gz", ".bz2", ".xz", ".bin", ".dmg", ".msix", ".deb",
    ".mp4", ".webm", ".mkv", ".mov", ".avi", ".mp3", ".flac",
    ".wav", ".jpg", ".jpeg", ".png", ".gif", ".webp", ".srt",
    ".epub", ".csv", ".json", ".txt", ".blend", ".vrm", ".pptx",
}
BG = "#16151f"
PANEL = "#211d2d"
FG = "#ede6f7"
MUTED = "#ad9cbe"
ACCENT = "#ad75df"
ERROR = "#f1a5aa"


def url_is_valid(value: str) -> bool:
    try:
        p = urllib.parse.urlsplit(value)
        return p.scheme.lower() in ("http", "https") and bool(p.netloc)
    except ValueError:
        return False


def detect_mode(url: str, requested: str) -> str:
    if requested in ("Video page", "Direct file"):
        return "video" if requested == "Video page" else "file"
    ext = Path(urllib.parse.unquote(urllib.parse.urlsplit(url).path)).suffix.lower()
    return "file" if ext in DIRECT_EXTENSIONS else "video"


def safe_filename(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip().rstrip(". ")
    if not name or name in {".", ".."}:
        name = "download.bin"
    root = name.split(".")[0].upper()
    if root in {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}:
        name = "_" + name
    return name[:180]


def direct_filename(url: str) -> str:
    filename = Path(urllib.parse.unquote(urllib.parse.urlsplit(url).path)).name
    return safe_filename(filename or "download.bin")


def parse_percent(line: str) -> str | None:
    hits = re.findall(r"(?<!\d)(\d{1,3}(?:\.\d+)?)%", line)
    if hits:
        value = float(hits[-1])
        if 0 <= value <= 100:
            return f"{value:.1f}%"
    return None


def subprocess_flags() -> int:
    return getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0


def stop_process(proc: subprocess.Popen | None) -> None:
    if proc is None or proc.poll() is not None:
        return
    try:
        if os.name == "nt":
            subprocess.run(
                ["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=subprocess_flags(), timeout=6,
            )
        else:
            proc.terminate()
        if proc.poll() is None:
            proc.terminate()
    except (OSError, subprocess.TimeoutExpired):
        try:
            proc.terminate()
        except OSError:
            pass


class DownloadDesk:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(f"{APP_NAME} v{APP_VERSION}")
        self.root.geometry("1030x750")
        self.root.minsize(820, 640)
        self.root.configure(background=BG)
        self.events: queue.Queue = queue.Queue()
        self.jobs: list[dict] = []
        self.active_job_id: str | None = None
        self.active_stop: threading.Event | None = None
        self.active_proc: subprocess.Popen | None = None
        self.conversion_proc: subprocess.Popen | None = None
        self.converting = False
        self.running = True
        self.auto_run = False
        self._restore()
        self._style()
        self._create_ui()
        self._refresh_tree()
        self.root.after(110, self._pump)
        self.root.protocol("WM_DELETE_WINDOW", self._close)
        self._log("Ready. yt-dlp handles video pages; aria2c improves direct downloads if installed.")
        if shutil.which("ffmpeg") is None:
            self._log("FFmpeg is not detected in PATH. MP4 conversion will be unavailable until it is installed.")
        if shutil.which("aria2c") is None:
            self._log("aria2c is optional and not detected. Direct downloads will use safe single-stream Python resume.")

    def _style(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure(".", background=BG, foreground=FG, font=("Segoe UI", 10))
        s.configure("TFrame", background=BG)
        s.configure("TLabel", background=BG, foreground=FG)
        s.configure("Title.TLabel", font=("Segoe UI Semibold", 19), foreground="#d6b0f1")
        s.configure("Secondary.TLabel", foreground=MUTED)
        s.configure("TButton", padding=(11, 7), background=PANEL, foreground=FG, borderwidth=1)
        s.map("TButton", background=[("active", "#413051")])
        s.configure("Accent.TButton", background="#69408a", foreground="white")
        s.map("Accent.TButton", background=[("active", "#8755af")])
        s.configure("TEntry", fieldbackground="#2a2438", foreground=FG, insertcolor=FG)
        s.configure("TCombobox", fieldbackground="#2a2438", background=PANEL, foreground=FG)
        s.map("TCombobox", fieldbackground=[("readonly", "#2a2438")], foreground=[("readonly", FG)])
        s.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=FG, rowheight=30, borderwidth=0)
        s.map("Treeview", background=[("selected", "#68468a")], foreground=[("selected", "white")])
        s.configure("Treeview.Heading", background="#332a43", foreground=FG, relief="flat")
        s.configure("TProgressbar", troughcolor="#30263c", background=ACCENT)

    def _create_ui(self):
        main = ttk.Frame(self.root, padding=16)
        main.pack(fill="both", expand=True)
        ttk.Label(main, text="Lilith Download Desk", style="Title.TLabel").pack(anchor="w")
        ttk.Label(main, text="Save videos to share with AI agents • Resume interrupted files • Prepare smaller MP4 clips", style="Secondary.TLabel").pack(anchor="w", pady=(0, 14))

        line = ttk.Frame(main)
        line.pack(fill="x", pady=(0, 8))
        ttk.Label(line, text="Download URL").pack(side="left", padx=(0, 9))
        self.url_var = tk.StringVar()
        self.url_entry = ttk.Entry(line, textvariable=self.url_var)
        self.url_entry.pack(side="left", fill="x", expand=True)
        ttk.Button(line, text="Paste", command=self._paste).pack(side="left", padx=(8, 0))

        controls = ttk.Frame(main)
        controls.pack(fill="x", pady=(0, 9))
        ttk.Label(controls, text="Type").pack(side="left")
        self.mode_var = tk.StringVar(value="Auto detect")
        ttk.Combobox(controls, textvariable=self.mode_var, state="readonly", width=14,
                     values=["Auto detect", "Video page", "Direct file"]).pack(side="left", padx=(7, 17))
        ttk.Label(controls, text="Video quality").pack(side="left")
        self.quality_var = tk.StringVar(value="Best")
        ttk.Combobox(controls, textvariable=self.quality_var, state="readonly", width=12,
                     values=["Best", "1080p max", "720p max"]).pack(side="left", padx=(7, 17))
        ttk.Label(controls, text="Browser login").pack(side="left")
        self.cookie_var = tk.StringVar(value="None")
        ttk.Combobox(controls, textvariable=self.cookie_var, state="readonly", width=11,
                     values=["None", "Chrome", "Edge", "Firefox", "Brave"]).pack(side="left", padx=(7, 0))

        folder_line = ttk.Frame(main)
        folder_line.pack(fill="x", pady=(0, 11))
        ttk.Label(folder_line, text="Save to").pack(side="left", padx=(0, 11))
        self.folder_var = tk.StringVar(value=str(DEFAULT_DOWNLOADS))
        ttk.Entry(folder_line, textvariable=self.folder_var).pack(side="left", fill="x", expand=True)
        ttk.Button(folder_line, text="Browse", command=self._browse_folder).pack(side="left", padx=(8, 0))
        ttk.Button(folder_line, text="Open folder", command=self._open_folder).pack(side="left", padx=(7, 0))

        buttons = ttk.Frame(main)
        buttons.pack(fill="x", pady=(0, 15))
        ttk.Button(buttons, text="+ Add download", style="Accent.TButton", command=self._add).pack(side="left", padx=(0, 9))
        ttk.Button(buttons, text="▶ Start queue", command=self._start).pack(side="left", padx=(0, 9))
        ttk.Button(buttons, text="Ⅱ Pause selected", command=self._pause_selected).pack(side="left", padx=(0, 9))
        ttk.Button(buttons, text="↻ Resume selected", command=self._resume_selected).pack(side="left", padx=(0, 9))
        ttk.Button(buttons, text="Remove", command=self._remove_selected).pack(side="left")

        self.tree = ttk.Treeview(main, columns=("mode", "status", "progress", "folder"), show="tree headings", height=8)
        self.tree.heading("#0", text="Link / File")
        self.tree.heading("mode", text="Type")
        self.tree.heading("status", text="Status")
        self.tree.heading("progress", text="Progress")
        self.tree.heading("folder", text="Destination")
        self.tree.column("#0", width=295, stretch=True)
        self.tree.column("mode", width=85, stretch=False)
        self.tree.column("status", width=100, stretch=False)
        self.tree.column("progress", width=80, stretch=False)
        self.tree.column("folder", width=250, stretch=True)
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._update_selection)

        prep = ttk.Frame(main)
        prep.pack(fill="x", pady=(14, 7))
        ttk.Label(prep, text="Prepare video for AI sharing:", style="Secondary.TLabel").pack(side="left")
        ttk.Button(prep, text="Convert / compress to MP4 (H.264, 720p)", command=self._convert_dialog).pack(side="left", padx=(10, 0))
        ttk.Label(prep, text="Optional clip range below", style="Secondary.TLabel").pack(side="left", padx=(12, 0))

        trim = ttk.Frame(main)
        trim.pack(fill="x", pady=(0, 8))
        ttk.Label(trim, text="Start (seconds)").pack(side="left")
        self.trim_start = tk.StringVar()
        ttk.Entry(trim, width=9, textvariable=self.trim_start).pack(side="left", padx=(7, 18))
        ttk.Label(trim, text="Duration (seconds)").pack(side="left")
        self.trim_duration = tk.StringVar()
        ttk.Entry(trim, width=9, textvariable=self.trim_duration).pack(side="left", padx=(7, 0))
        ttk.Label(trim, text="Leave blank to convert the whole video", style="Secondary.TLabel").pack(side="left", padx=(14, 0))

        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(main, textvariable=self.status_var, style="Secondary.TLabel").pack(anchor="w", pady=(4, 5))
        self.log_box = tk.Text(main, height=7, bg="#15121d", fg="#c9bbd7", insertbackground=FG,
                               font=("Consolas", 9), wrap="word", state="disabled", relief="flat")
        self.log_box.pack(fill="x")

        self.url_entry.focus_set()

    def _paste(self):
        try:
            self.url_var.set(self.root.clipboard_get().strip())
        except tk.TclError:
            messagebox.showinfo("Clipboard", "No text URL is available on the clipboard.")

    def _browse_folder(self):
        folder = filedialog.askdirectory(initialdir=self.folder_var.get() or str(Path.home()))
        if folder:
            self.folder_var.set(folder)

    def _open_folder(self):
        folder = Path(self.folder_var.get()).expanduser()
        folder.mkdir(parents=True, exist_ok=True)
        try:
            if os.name == "nt":
                os.startfile(str(folder))
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(folder)])
            else:
                subprocess.Popen(["xdg-open", str(folder)])
        except OSError as exc:
            messagebox.showerror("Open folder", str(exc))

    def _add(self):
        url = self.url_var.get().strip()
        if not url_is_valid(url):
            messagebox.showerror("Invalid URL", "Paste a full http:// or https:// URL.")
            return
        folder = str(Path(self.folder_var.get()).expanduser())
        try:
            Path(folder).mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            messagebox.showerror("Folder error", str(exc))
            return
        mode = detect_mode(url, self.mode_var.get())
        job = {
            "id": str(uuid.uuid4()), "url": url, "mode": mode, "folder": folder,
            "quality": self.quality_var.get(), "cookies": self.cookie_var.get(),
            "status": "Queued", "progress": "0%", "output": "",
        }
        self.jobs.append(job)
        self._save()
        self._refresh_tree()
        self.tree.selection_set(job["id"])
        self.tree.see(job["id"])
        self.url_var.set("")
        self._log(f"Added {mode} download: {urllib.parse.urlsplit(url).netloc}")
        if self.auto_run:
            self._maybe_start_next()

    def _selected(self) -> dict | None:
        selected = self.tree.selection()
        if not selected:
            return None
        return next((x for x in self.jobs if x["id"] == selected[0]), None)

    def _update_selection(self, _event=None):
        job = self._selected()
        if job:
            self.status_var.set(f"{job['status']}: {job['url'][:130]}")

    def _refresh_tree(self):
        old = self.tree.selection() if hasattr(self, "tree") else ()
        for item in self.tree.get_children():
            self.tree.delete(item)
        for job in self.jobs:
            display = Path(job["output"]).name if job.get("output") else job["url"].split("?")[0]
            if len(display) > 110:
                display = display[:107] + "..."
            self.tree.insert("", "end", iid=job["id"], text=display, values=(
                job["mode"], job["status"], job["progress"], job["folder"]
            ))
        for iid in old:
            if self.tree.exists(iid):
                self.tree.selection_add(iid)

    def _refresh_row(self, job: dict):
        if self.tree.exists(job["id"]):
            display = Path(job["output"]).name if job.get("output") else job["url"].split("?")[0]
            if len(display) > 110:
                display = display[:107] + "..."
            self.tree.item(job["id"], text=display, values=(job["mode"], job["status"], job["progress"], job["folder"]))

    def _start(self):
        self.auto_run = True
        self._maybe_start_next()

    def _maybe_start_next(self):
        if not self.running or not self.auto_run or self.active_job_id:
            return
        job = next((x for x in self.jobs if x["status"] == "Queued"), None)
        if job is None:
            self.auto_run = False
            self.status_var.set("Queue complete (or no queued items)")
            return
        self.active_job_id = job["id"]
        self.active_stop = threading.Event()
        job["status"] = "Downloading"
        self._refresh_row(job)
        self._save()
        self.status_var.set(f"Downloading: {urllib.parse.urlsplit(job['url']).netloc}")
        threading.Thread(target=self._download_worker, args=(job.copy(), self.active_stop), daemon=True).start()

    def _pause_selected(self):
        job = self._selected()
        if not job:
            return
        if job["status"] == "Downloading" and job["id"] == self.active_job_id:
            job["status"] = "Pausing"
            if self.active_stop:
                self.active_stop.set()
            stop_process(self.active_proc)
        elif job["status"] == "Queued":
            job["status"] = "Paused"
        self._refresh_row(job)
        self._save()

    def _resume_selected(self):
        job = self._selected()
        if not job or job["status"] not in ("Paused", "Failed"):
            return
        job["status"] = "Queued"
        self._refresh_row(job)
        self._save()
        self.auto_run = True
        self._maybe_start_next()

    def _remove_selected(self):
        job = self._selected()
        if not job:
            return
        if job["id"] == self.active_job_id:
            messagebox.showinfo("Pause first", "Pause this download, then remove it. Partial files are never deleted automatically.")
            return
        self.jobs = [x for x in self.jobs if x["id"] != job["id"]]
        self._refresh_tree()
        self._save()
        self._maybe_start_next()

    def _download_worker(self, job: dict, stop: threading.Event):
        try:
            if job["mode"] == "video":
                output = self._download_video(job, stop)
            elif shutil.which("aria2c"):
                output = self._download_aria2(job, stop)
            else:
                output = self._download_python(job, stop)
            self.events.put(("done", job["id"], bool(not stop.is_set()), output or ""))
        except Exception as exc:
            self.events.put(("error", job["id"], str(exc)))

    def _run_command(self, cmd: list[str], job: dict, stop: threading.Event) -> str:
        output = ""
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                stdin=subprocess.DEVNULL, text=True, encoding="utf-8", errors="replace",
                                bufsize=1, creationflags=subprocess_flags())
        self.active_proc = proc
        try:
            assert proc.stdout is not None
            for raw in proc.stdout:
                if stop.is_set():
                    stop_process(proc)
                    break
                line = raw.strip()
                if not line:
                    continue
                if line.startswith("OUTPUT_FILE:"):
                    output = line.split(":", 1)[1].strip()
                percent = parse_percent(line)
                if percent and ("[download]" in line or "%" in line):
                    self.events.put(("progress", job["id"], percent))
                if not (line.startswith("[download]") and percent):
                    self.events.put(("log", line[:320]))
            try:
                code = proc.wait(timeout=8)
            except subprocess.TimeoutExpired:
                stop_process(proc)
                code = proc.wait(timeout=4)
            if code != 0 and not stop.is_set():
                raise RuntimeError(f"Downloader exited with error code {code}. See the log for details.")
            return output
        finally:
            self.active_proc = None
            try:
                if proc.stdout:
                    proc.stdout.close()
            except OSError:
                pass

    def _download_video(self, job: dict, stop: threading.Event) -> str:
        try:
            import yt_dlp  # noqa: F401
        except ImportError as exc:
            raise RuntimeError("yt-dlp is missing. Run Install_and_Launch.bat or: py -m pip install -U 'yt-dlp[default]'") from exc
        cmd = [sys.executable, "-m", "yt_dlp", "--newline", "--continue", "--no-overwrites",
               "--no-playlist", "--windows-filenames", "--retries", "10", "--fragment-retries", "10",
               "--socket-timeout", "30", "--concurrent-fragments", "4",
               "--merge-output-format", "mp4", "--print", "after_move:OUTPUT_FILE:%(filepath)s",
               "-o", str(Path(job["folder"]) / "%(title).150s [%(id)s].%(ext)s")]
        if job["quality"] == "1080p max":
            cmd.extend(["-f", "bv*[height<=1080]+ba/b[height<=1080]/b"])
        elif job["quality"] == "720p max":
            cmd.extend(["-f", "bv*[height<=720]+ba/b[height<=720]/b"])
        else:
            cmd.extend(["-f", "bv*+ba/b"])
        if job["cookies"] != "None":
            cmd.extend(["--cookies-from-browser", job["cookies"].lower()])
        cmd.extend(["--", job["url"]])
        self.events.put(("log", "Video downloader started."))
        return self._run_command(cmd, job, stop)

    def _download_aria2(self, job: dict, stop: threading.Event) -> str:
        cmd = ["aria2c", "--continue=true", "--always-resume=true", "--split=8",
               "--max-connection-per-server=8", "--min-split-size=1M", "--max-tries=10",
               "--retry-wait=4", "--timeout=30", "--connect-timeout=25",
               "--file-allocation=none", "--summary-interval=1", "--console-log-level=notice",
               "--dir", job["folder"], "--", job["url"]]
        self.events.put(("log", "aria2c started (8 connections max; resume requested)."))
        return self._run_command(cmd, job, stop)

    def _download_python(self, job: dict, stop: threading.Event) -> str:
        """Safe fallback direct-download engine: persists .part files and refuses unsafe restart."""
        filename = direct_filename(job["url"])
        dest = Path(job["folder"]) / filename
        part = Path(str(dest) + ".part")
        meta_path = Path(str(part) + ".meta.json")
        if dest.exists():
            raise RuntimeError(f"Destination already exists: {dest.name}. Move/rename it before retrying.")
        resume_at = part.stat().st_size if part.exists() else 0
        headers = {"User-Agent": "LilithDownloadDesk/1.0 (compatible; Python urllib)"}
        if resume_at:
            headers["Range"] = f"bytes={resume_at}-"
            if meta_path.exists():
                try:
                    meta = json.loads(meta_path.read_text(encoding="utf-8"))
                    if meta.get("url") == job["url"] and meta.get("if_range"):
                        headers["If-Range"] = meta["if_range"]
                except (OSError, ValueError):
                    pass
        request = urllib.request.Request(job["url"], headers=headers)
        try:
            response = urllib.request.urlopen(request, timeout=30)
        except urllib.error.HTTPError as exc:
            if exc.code == 416 and resume_at:
                raise RuntimeError("Server rejected the saved resume offset (416); partial file was kept intact.") from exc
            raise RuntimeError(f"HTTP {exc.code}: {exc.reason}") from exc
        with response:
            status = response.status
            if resume_at and status != 206:
                raise RuntimeError("Server cannot resume this partial download (no HTTP 206). Existing .part was preserved.")
            if resume_at:
                content_range = response.headers.get("Content-Range", "")
                match = re.match(r"bytes\s+(\d+)-(\d+)/(\d+|\*)", content_range)
                if not match or int(match.group(1)) != resume_at:
                    raise RuntimeError("Server returned a mismatched byte range; existing .part was preserved.")
                total = int(match.group(3)) if match.group(3) != "*" else None
            else:
                length = response.headers.get("Content-Length")
                total = int(length) if length and length.isdigit() else None
                validator = response.headers.get("ETag") or response.headers.get("Last-Modified")
                try:
                    meta_path.write_text(json.dumps({"url": job["url"], "if_range": validator}), encoding="utf-8")
                except OSError:
                    pass
            self.events.put(("log", f"Direct HTTP download: {filename} ({'resuming' if resume_at else 'new'})."))
            count = resume_at
            last_report = 0.0
            with part.open("ab" if resume_at else "wb") as f:
                while not stop.is_set():
                    chunk = response.read(256 * 1024)
                    if not chunk:
                        break
                    f.write(chunk)
                    count += len(chunk)
                    now = time.monotonic()
                    if now - last_report >= 0.35:
                        self.events.put(("progress", job["id"], f"{count / total * 100:.1f}%" if total else f"{count / 1048576:.1f} MiB"))
                        last_report = now
            if stop.is_set():
                return ""
            if total is not None and count != total:
                raise RuntimeError(f"Incomplete transfer ({count} of {total} bytes); .part preserved for resume.")
            os.replace(part, dest)
            try:
                meta_path.unlink(missing_ok=True)
            except OSError:
                pass
            self.events.put(("progress", job["id"], "100%"))
            return str(dest)

    def _convert_dialog(self):
        if self.converting:
            messagebox.showinfo("Conversion", "A video is already being converted.")
            return
        if not shutil.which("ffmpeg"):
            messagebox.showerror("FFmpeg missing", "FFmpeg is required for video conversion. Install it and restart the app.")
            return
        src = filedialog.askopenfilename(title="Choose a video to prepare for AI",
                                         filetypes=[("Video files", "*.mp4 *.mkv *.mov *.webm *.avi *.ts *.m4v"), ("All files", "*.*")])
        if not src:
            return
        try:
            start = self._parse_positive(self.trim_start.get(), "Start time", zero_ok=True)
            duration = self._parse_positive(self.trim_duration.get(), "Duration", zero_ok=False)
        except ValueError as exc:
            messagebox.showerror("Clip settings", str(exc))
            return
        initial = str(Path(src).with_name(Path(src).stem + "_AI_720p.mp4"))
        output = filedialog.asksaveasfilename(title="Save AI-friendly MP4", defaultextension=".mp4",
                                              initialdir=str(Path(src).parent), initialfile=Path(initial).name,
                                              filetypes=[("MP4 video", "*.mp4")])
        if not output:
            return
        if Path(src).resolve() == Path(output).resolve():
            messagebox.showerror("Output", "Choose a different filename from the source video.")
            return
        if Path(output).exists():
            messagebox.showerror("Output", "The output file already exists. Choose a new filename.")
            return
        self.converting = True
        self.status_var.set("Converting video for AI sharing...")
        threading.Thread(target=self._convert_worker, args=(src, output, start, duration), daemon=True).start()

    @staticmethod
    def _parse_positive(value: str, label: str, zero_ok: bool) -> float | None:
        value = value.strip()
        if not value:
            return None
        try:
            result = float(value)
        except ValueError as exc:
            raise ValueError(f"{label} must be a number of seconds.") from exc
        if not (result < float("inf")) or result < 0 or (not zero_ok and result == 0):
            raise ValueError(f"{label} must be {'nonnegative' if zero_ok else 'positive'}.")
        return result

    def _convert_worker(self, src: str, output: str, start: float | None, duration: float | None):
        # No upscaling; fit the image in a 1280x720 box while preserving its aspect ratio.
        filter_expr = "scale=w='min(1280,iw)':h='min(720,ih)':force_original_aspect_ratio=decrease:force_divisible_by=2"
        cmd = ["ffmpeg", "-hide_banner", "-nostdin", "-n"]
        if start is not None:
            cmd.extend(["-ss", str(start)])
        cmd.extend(["-i", src])
        if duration is not None:
            cmd.extend(["-t", str(duration)])
        cmd.extend(["-map", "0:v:0", "-map", "0:a:0?", "-vf", filter_expr,
                    "-r", "30", "-c:v", "libx264", "-preset", "veryfast", "-crf", "27",
                    "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "96k", "-sn",
                    "-movflags", "+faststart", output])
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    stdin=subprocess.DEVNULL, encoding="utf-8", errors="replace", text=True,
                                    creationflags=subprocess_flags())
            self.conversion_proc = proc
            assert proc.stdout is not None
            for raw in proc.stdout:
                line = raw.strip()
                if line and ("time=" in line or "Error" in line or "Invalid" in line):
                    self.events.put(("log", "Convert: " + line[:250]))
            code = proc.wait()
            if code:
                self.events.put(("convert_error", f"FFmpeg failed (exit {code}). Check log."))
            else:
                self.events.put(("convert_done", output))
        except Exception as exc:
            self.events.put(("convert_error", str(exc)))
        finally:
            self.conversion_proc = None

    def _log(self, message: str):
        if not self.running:
            return
        self.log_box.configure(state="normal")
        self.log_box.insert("end", message + "\n")
        line_count = int(self.log_box.index("end-1c").split(".")[0])
        if line_count > 300:
            self.log_box.delete("1.0", "75.0")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def _pump(self):
        if not self.running:
            return
        dirty = False
        try:
            while True:
                item = self.events.get_nowait()
                kind = item[0]
                if kind == "log":
                    self._log(item[1])
                elif kind == "progress":
                    job = next((x for x in self.jobs if x["id"] == item[1]), None)
                    if job:
                        job["progress"] = item[2]
                        self._refresh_row(job)
                elif kind in ("done", "error"):
                    job = next((x for x in self.jobs if x["id"] == item[1]), None)
                    if job:
                        stopped = self.active_stop.is_set() if self.active_stop else False
                        if stopped:
                            job["status"] = "Paused"
                            self._log("Paused. Partial download files were preserved.")
                        elif kind == "done" and item[2]:
                            job["status"] = "Completed"
                            job["progress"] = "100%"
                            if item[3]:
                                job["output"] = item[3]
                            self._log("Download completed.")
                        else:
                            job["status"] = "Failed"
                            self._log("Error: " + (item[2] if kind == "error" else "Download interrupted unexpectedly."))
                        self._refresh_row(job)
                        dirty = True
                    self.active_job_id = None
                    self.active_stop = None
                    self._maybe_start_next()
                elif kind == "convert_done":
                    self.converting = False
                    self.status_var.set("AI-friendly MP4 ready: " + str(item[1]))
                    self._log("Converted MP4: " + str(item[1]))
                    messagebox.showinfo("Conversion finished", "Saved AI-friendly MP4:\n" + str(item[1]))
                elif kind == "convert_error":
                    self.converting = False
                    self.status_var.set("Conversion failed")
                    self._log("Conversion failed: " + str(item[1]))
                    messagebox.showerror("Conversion failed", str(item[1]))
        except queue.Empty:
            pass
        if dirty:
            self._save()
        self.root.after(110, self._pump)

    def _restore(self):
        try:
            records = json.loads(JOBS_FILE.read_text(encoding="utf-8"))
            if not isinstance(records, list):
                return
            for job in records:
                if not isinstance(job, dict) or not url_is_valid(str(job.get("url", ""))):
                    continue
                if job.get("status") in ("Downloading", "Pausing", "Queued"):
                    job["status"] = "Paused"
                self.jobs.append(job)
        except (OSError, ValueError):
            pass

    def _save(self):
        try:
            APP_DIR.mkdir(parents=True, exist_ok=True)
            temp = JOBS_FILE.with_suffix(".tmp")
            temp.write_text(json.dumps(self.jobs, indent=2, ensure_ascii=False), encoding="utf-8")
            os.replace(temp, JOBS_FILE)
        except OSError as exc:
            self._log(f"Warning: unable to save job list: {exc}") if hasattr(self, "log_box") else None

    def _close(self):
        self.running = False
        if self.active_stop:
            self.active_stop.set()
        stop_process(self.active_proc)
        stop_process(self.conversion_proc)
        for job in self.jobs:
            if job["status"] in ("Downloading", "Pausing", "Queued"):
                job["status"] = "Paused"
        self._save()
        self.root.destroy()


def main():
    root = tk.Tk()
    DownloadDesk(root)
    root.mainloop()


if __name__ == "__main__":
    main()
