LILITH DOWNLOAD DESK 1.0
Windows local downloader with a simple dark GUI

QUICK START
1. Unzip this folder wherever you like.
2. Double-click Install_and_Launch.bat once. This installs the free yt-dlp Python package.
3. Next time, double-click Launch.bat.
4. Paste a video PAGE URL, choose Auto detect or Video page, and click + Add download.
5. For ZIPs, EXEs, MP4 links, etc. that point directly to a file, choose Direct file.
6. Click Start queue; use Pause selected / Resume selected as needed.
7. For sharing videos with AI tools, click Convert / compress to MP4 (H.264, 720p).
   Optionally enter a start time and duration in seconds before clicking convert.

DEPENDENCIES
Required: Python 3.10+ and yt-dlp; installer obtains yt-dlp from PyPI.
Optional: FFmpeg in PATH for joining video/audio and converting videos to MP4.
Optional: aria2c in PATH for fast multi-connection regular file downloads.
If aria2c isn't available, regular file downloads use a single-stream Python
HTTP downloader that saves .part files and attempts HTTP Range resume.

The video downloading functionality depends on each site's support in yt-dlp.
Some sites require an authenticated browser session. Browser login selection is
optional and explicitly uses yt-dlp's --cookies-from-browser function locally.
If browser cookie reading fails, close the browser and try again, or select None.
Do not upload your cookie database or private download URLs to AI tools.

IMPORTANT LIMITATIONS
- The app cannot download DRM-protected streams and does not bypass paywalls.
- Resume depends on the server honoring HTTP byte ranges and the URL staying valid.
- A link that expires or changes server-side can be impossible to resume.
- Direct download auto-detection uses the URL filename extension, so choose
  Direct file manually for links without a recognizable extension.
- Paused/failed partial files are never deleted automatically.
- Downloaded files may be copyrighted; use only where you have permission.
- Existing files are not intentionally overwritten.
- The job queue is stored locally in %LOCALAPPDATA%\LilithDownloadDesk\jobs.json.
  This file contains your original URL strings, including private query tokens.
  Keep the device and backup of this file private. Remove jobs when no longer needed.
- One download runs at a time to favor reliable pause/resume.
- Jobs restored after app closure start in Paused status. Select + Resume.

RECOMMENDED OPTIONAL DOWNLOADS
yt-dlp: https://github.com/yt-dlp/yt-dlp
aria2:  https://github.com/aria2/aria2/releases
FFmpeg: https://ffmpeg.org/download.html

TROUBLESHOOTING
Video fails: Update with Install_and_Launch.bat; check site's support and login.
Direct file fails: Try Direct file mode; if server denies resume, partial stays safe.
FFmpeg missing: Reopen after FFmpeg is added to PATH.
Browser buttons: The application is not a Chrome extension and does not
intercept network traffic or automatically detect playing videos.
